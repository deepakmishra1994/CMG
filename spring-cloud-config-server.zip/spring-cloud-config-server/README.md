# spring-cloud-config-server

Spring cloud config server for storing meru configurations