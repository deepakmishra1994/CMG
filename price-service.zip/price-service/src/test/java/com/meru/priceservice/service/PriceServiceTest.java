package com.meru.priceservice.service;

import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.when;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import com.meru.priceservice.dao.PriceRepository;
import com.meru.priceservice.entities.Price;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@RunWith(MockitoJUnitRunner.class)
public class PriceServiceTest {

    @InjectMocks
    private PriceService priceService;

    @Mock
    private PriceRepository priceRepository;

    private Price price;
    private List<Price> priceList;

    @Before
    public void init() {
        price=new Price(1L, 1001L, 200L, "INR");
        priceList= Arrays.asList(
                new Price(1L, 1001L, 200L, "INR"),
                new Price(2L, 1002L, 400L, "EUR"),
                new Price(3L, 1003L, 20L, "USD")
                );
    }

    @Test
    public void getPriceByProductId() {
        when(priceRepository.findByProductId(anyLong())).thenReturn(Optional.of(price));

        Price price=priceService.getPriceByProductId(1L);

        assertEquals("200INR",price.getPrice()+price.getCurrency());
    }

    @Test
    public void getPriceByProductIds() throws Exception{
        when(priceRepository.findByProductIdIn(anyList())).thenReturn(priceList);
        List<Price> returnedPriceList=priceService.getPriceByProductIds(new ArrayList<>(Arrays.asList(1001L,1002L,1003L)));

        assertTrue(priceList.size()==returnedPriceList.size());
        assertEquals("200INR",returnedPriceList.get(0).getPrice()+returnedPriceList.get(0).getCurrency());
    }
}