package com.meru.priceservice.dao;

import com.meru.priceservice.entities.Price;
import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@RunWith(SpringRunner.class)
@DataJpaTest
public class PriceRepositoryTest {

    @Autowired
    private PriceRepository priceRepository;

    @Test
    public void findByProductId() {
        Price price=priceRepository.findByProductId(1001L).get();
        assertEquals("INR",price.getCurrency());
    }

    @Test
    public void findByProductIdIn() {
        List<Price> priceList=priceRepository.findByProductIdIn(new ArrayList<>(Arrays.asList(1001L,1002L,1003L)));
        assertEquals(3,priceList.size());
    }
}