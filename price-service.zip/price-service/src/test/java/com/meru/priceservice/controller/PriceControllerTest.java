package com.meru.priceservice.controller;

import static org.mockito.Mockito.when;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.any;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.meru.priceservice.entities.Price;
import com.meru.priceservice.service.IPriceService;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.MvcResult;

import java.util.Arrays;

@RunWith(SpringRunner.class)
@WebMvcTest(value=PriceController.class,secure = false)
public class PriceControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private IPriceService iPriceService;

    @Test
    public void getPriceByProductId() throws Exception {

        //mocking the price service
        when(iPriceService.getPriceByProductId(anyLong()))
            .thenReturn(new Price(1L,1001L,200L,"INR"));

        //sending the request using mockRequestBuilders
        RequestBuilder request=MockMvcRequestBuilders
            .get("/price/1001")
            .accept(MediaType.APPLICATION_JSON);

        MvcResult result=mockMvc.perform(request)
            .andExpect(status().isOk())
            .andExpect(content().json("{price: {priceId: 1,productId: 1001,price: 200,currency: INR},errorMessage: null}"))
            .andReturn();

        //String expected="{price: {priceId: 1,productId: 1001,price: 200,currency: INR},errorMessage: null}";
        //String actual=result.getResponse().getContentAsString();
        //JSONAssert.assertEquals(expected, actual, false);
    }

    @Test
    public void addPrice() throws Exception {

        String body="{\"productId\": 1004,\"price\": 2500,\"currency\": \"USD\"}";

        Price mockPrice= new Price(4L,1004L,2500L,"USD");

        when(iPriceService.addPrice(any(Price.class))).thenReturn(mockPrice);

        RequestBuilder request=MockMvcRequestBuilders
                .post("/price")
                .accept(MediaType.APPLICATION_JSON)
                .content(body)
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result=mockMvc.perform(request)
                .andExpect(status().isCreated())
                .andExpect(content().json("{price: {priceId: 4,productId: 1004,price: 2500,currency: USD},errorMessage: null}"))
                .andReturn();
    }

    @Test
    public void updatePriceByProductId() throws Exception {
        String body="{\"productId\": 1004,\"price\": 2700,\"currency\": \"USD\"}";

        Price mockPrice= new Price(4L,1004L,2700L,"USD");

        when(iPriceService.updatePriceByProductId(anyLong(),any(Price.class))).thenReturn(mockPrice);

        RequestBuilder request=MockMvcRequestBuilders
                .put("/price/1004")
                .accept(MediaType.APPLICATION_JSON)
                .content(body)
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result=mockMvc.perform(request)
                .andExpect(status().isOk())
                .andExpect(content().json("{price: {priceId: 4,productId: 1004,price: 2700,currency: USD},errorMessage: null}"))
                .andReturn();
    }

    @Test
    public void deletePriceByProductId() throws Exception {

        RequestBuilder request=MockMvcRequestBuilders
                .delete("/price/1004")
                .accept(MediaType.APPLICATION_JSON);

        MvcResult result=mockMvc.perform(request)
                .andExpect(status().isOk())
                .andExpect(content().json("{message : \"Deleted Successfully\"}"))
                .andReturn();
    }

    @Test
    public void getPriceByProductIds() throws Exception {
        String body="[1001,1002,1003]";

        when(iPriceService.getPriceByProductIds(Mockito.anyList())).thenReturn(
                Arrays.asList(new Price(1L,1001L,200L,"INR"),
                        new Price(2L,1002L,400L,"EUR"),
                        new Price(3L,1003L,20L,"USD"))
        );
        RequestBuilder request=MockMvcRequestBuilders
                .post("/price/getPriceByProductIds")
                .accept(MediaType.APPLICATION_JSON)
                .content(body)
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result=mockMvc.perform(request)
                .andExpect(status().isOk())
                .andExpect(content().json("" +
                        "[" +
                            "{priceId: 1,productId: 1001,price: 200,currency: INR}," +
                            "{priceId: 2,productId: 1002,price: 400,currency: EUR}," +
                            "{priceId: 3,productId: 1003,price: 20,currency: USD}" +
                        "]"))
                .andReturn();
    }
}