package com.meru.priceservice.dto;

import com.meru.priceservice.entities.Price;

public class PriceDTO {

    private Price price;
    private String errorMessage;

    public Price getPrice() {
        return price;
    }

    public void setPrice(Price price) {
        this.price = price;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    @Override
    public String toString() {
        return "PriceDTO{" +
                "price=" + price +
                ", errorMessage='" + errorMessage + '\'' +
                '}';
    }
}
