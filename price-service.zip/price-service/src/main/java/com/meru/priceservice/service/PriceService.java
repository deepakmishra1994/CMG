package com.meru.priceservice.service;

import com.meru.priceservice.dao.PriceRepository;
import com.meru.priceservice.entities.Price;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.Optional;

@Service
public class PriceService implements IPriceService{

    @Autowired
    private PriceRepository priceRepository;

    @Override
    public Price getPriceByProductId(Long productId) throws EntityNotFoundException {
        Optional<Price> price = priceRepository.findByProductId(productId);
        if (!price.isPresent())
            throw new EntityNotFoundException("Price record not found for the given product id :" + productId);
        return price.get();
    }

    @Override
    public Price addPrice(Price price) throws IllegalAccessException {
        if (price.getProductId()==null)
            throw new IllegalAccessException("You must specify the productId to add price of the product");

        return priceRepository.save(price);
    }

    @Override
    public Price updatePriceByProductId(Long productId, Price price) throws EntityNotFoundException {
        Price priceEntity=getPriceByProductId(productId);
        if (priceEntity == null)
            throw new EntityNotFoundException(
                    "Price record not found for the given product id " + priceEntity.getProductId());

        priceEntity.setPriceId(priceEntity.getPriceId());
        priceEntity.setPrice(price.getPrice());
        priceEntity.setProductId(price.getProductId());
        priceEntity.setCurrency(price.getCurrency());
        priceEntity= priceRepository.save(priceEntity);

        return priceEntity;
    }

    @Override
    public void deletePriceByProductId(Long productId) {
        Price price=getPriceByProductId(productId);
        priceRepository.deleteById(price.getPriceId());
    }
}
