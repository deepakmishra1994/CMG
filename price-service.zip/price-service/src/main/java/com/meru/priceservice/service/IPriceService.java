package com.meru.priceservice.service;

import com.meru.priceservice.entities.Price;

import javax.persistence.EntityNotFoundException;

public interface IPriceService {
    Price getPriceByProductId(Long productId) throws EntityNotFoundException;
    Price addPrice(Price price) throws IllegalAccessException;
    Price updatePriceByProductId(Long productId,Price price) throws EntityNotFoundException;
    void deletePriceByProductId(Long productId);
}
