package com.meru.priceservice.controller;

import com.meru.priceservice.dto.PriceDTO;
import com.meru.priceservice.entities.Price;
import com.meru.priceservice.service.PriceService;
import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.persistence.EntityNotFoundException;

@RestController
public class PriceController {

    @Autowired
    private PriceService priceService;

    /**
     * Get price by productId of product microservice
     * @param productId
     * @return
     */
    @GetMapping(value = "/price/{product_id}", produces = {"application/json", "application/xml"} )
    public ResponseEntity<PriceDTO> getPriceByProductId(@PathVariable("product_id")Long productId){

        PriceDTO priceDTO=new PriceDTO();
        ResponseEntity<PriceDTO> responseEntity;

        try{
            Price priceReturned=priceService.getPriceByProductId(productId);
            priceDTO.setPrice(priceReturned);
            responseEntity = new ResponseEntity<>(priceDTO, HttpStatus.OK);
        } catch (EntityNotFoundException ex) {
            ex.printStackTrace();
            priceDTO.setErrorMessage(ex.getMessage());
            responseEntity = new ResponseEntity<>(priceDTO, HttpStatus.NOT_FOUND);
        } catch (HibernateException ex) {
            ex.printStackTrace();
            priceDTO.setErrorMessage(ex.getMessage());
            responseEntity = new ResponseEntity<>(priceDTO, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception ex) {
            ex.printStackTrace();
            priceDTO.setErrorMessage(ex.getMessage());
            responseEntity = new ResponseEntity<>(priceDTO, HttpStatus.INTERNAL_SERVER_ERROR);
        }
            return responseEntity;
    }

    /**
     * Saving the price for product
     * @param price
     * @return
     */
    @PostMapping(value = "/price", consumes = "application/json", produces = "application/json")
    public ResponseEntity<PriceDTO> addPrice(@RequestBody Price price){
        PriceDTO PriceDTO = new PriceDTO();
        ResponseEntity<PriceDTO> responseEntity;
        try {
            Price priceReturned = priceService.addPrice(price);
            PriceDTO.setPrice(priceReturned);
            responseEntity = new ResponseEntity<>(PriceDTO, HttpStatus.CREATED);
        } catch (IllegalAccessException ex) {
            ex.printStackTrace();
            PriceDTO.setErrorMessage(ex.getMessage());
            responseEntity = new ResponseEntity<>(PriceDTO, HttpStatus.NOT_ACCEPTABLE);
        } catch (HibernateException ex) {
            ex.printStackTrace();
            PriceDTO.setErrorMessage(ex.getMessage());
            responseEntity = new ResponseEntity<>(PriceDTO, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception ex) {
            ex.printStackTrace();
            PriceDTO.setErrorMessage(ex.getMessage());
            responseEntity = new ResponseEntity<>(PriceDTO, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return responseEntity;
    }

    /**
     * Updating the price
     * @param price
     * @param productId
     * @return
     */
    @PutMapping(value = "/price/{product_id}", consumes = "application/json", produces = "application/json")
    public ResponseEntity<PriceDTO> updatePriceByProductId(@RequestBody Price price,@PathVariable("product_id")Long productId){
        PriceDTO priceDTO = new PriceDTO();
        ResponseEntity<PriceDTO> responseEntity;
        try {
            Price priceReturned = priceService.updatePriceByProductId(productId, price);
            priceDTO.setPrice(priceReturned);
            responseEntity = new ResponseEntity<>(priceDTO, HttpStatus.OK);

        } catch (EntityNotFoundException ex) {
            ex.printStackTrace();
            priceDTO.setErrorMessage(ex.getMessage());
            responseEntity = new ResponseEntity<>(priceDTO, HttpStatus.NOT_FOUND);

        } catch (HibernateException ex) {
            ex.printStackTrace();
            priceDTO.setErrorMessage(ex.getMessage());
            responseEntity = new ResponseEntity<>(priceDTO, HttpStatus.INTERNAL_SERVER_ERROR);

        } catch (Exception ex) {

            ex.printStackTrace();
            priceDTO.setErrorMessage(ex.getMessage());
            responseEntity = new ResponseEntity<>(priceDTO, HttpStatus.INTERNAL_SERVER_ERROR);

        }

        return responseEntity;
    }

    /**
     * Deleting the price
     * @param productId
     * @return
     */
    @DeleteMapping(value = "/price/{product_id}", consumes = "application/json", produces = "application/json")
    public @ResponseBody ResponseEntity<String> deletePriceByProductId(@PathVariable("product_id")Long productId){
        ResponseEntity<String> responseEntity;
        PriceDTO priceDTO = new PriceDTO();
        try {
            priceService.deletePriceByProductId(productId);
            responseEntity = new ResponseEntity<>("{\"message\" : \"Deleted Successfully\"}", HttpStatus.OK);

        } catch (EntityNotFoundException ex) {
            ex.printStackTrace();
            priceDTO.setErrorMessage(ex.getMessage());
            responseEntity = new ResponseEntity<>("{\"message\" : \"Not Found\"}", HttpStatus.NOT_FOUND);

        } catch (HibernateException ex) {
            ex.printStackTrace();
            priceDTO.setErrorMessage(ex.getMessage());
            responseEntity = new ResponseEntity<>("{\"message\" : \"Data related error encountered\"}", HttpStatus.INTERNAL_SERVER_ERROR);

        } catch (Exception ex) {
            ex.printStackTrace();
            priceDTO.setErrorMessage(ex.getMessage());
            responseEntity = new ResponseEntity<>("Cannot Delete because id is referential", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }
}
