package com.meru.priceservice.controller;

import com.meru.priceservice.dto.PriceDTO;
import com.meru.priceservice.entities.Price;

import com.meru.priceservice.service.IPriceService;
import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.persistence.EntityNotFoundException;
import java.util.List;

@RestController
public class PriceController {

    @Autowired
    private IPriceService iPriceService;

    /**
     * Get price by productId of product microservice
     * @param productId
     * @return PriceDTO
     */
    @GetMapping(value = "/price/{product_id}")
    public ResponseEntity<PriceDTO> getPriceByProductId(@PathVariable("product_id")Long productId){

        PriceDTO priceDTO=new PriceDTO();
        ResponseEntity<PriceDTO> responseEntity;

        try{
            Price priceReturned=iPriceService.getPriceByProductId(productId);
            priceDTO.setPrice(priceReturned);
            responseEntity = new ResponseEntity<>(priceDTO, HttpStatus.OK);
        } catch (EntityNotFoundException ex) {
            ex.printStackTrace();
            priceDTO.setErrorMessage(ex.getMessage());
            responseEntity = new ResponseEntity<>(priceDTO, HttpStatus.NOT_FOUND);
        } catch (HibernateException ex) {
            ex.printStackTrace();
            priceDTO.setErrorMessage(ex.getMessage());
            responseEntity = new ResponseEntity<>(priceDTO, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception ex) {
            ex.printStackTrace();
            priceDTO.setErrorMessage(ex.getMessage());
            responseEntity = new ResponseEntity<>(priceDTO, HttpStatus.INTERNAL_SERVER_ERROR);
        }
            return responseEntity;
    }

    /**
     * Saving the price for product
     * @param price
     * @return PriceDTO
     */
    @PostMapping(value = "/price")
    public ResponseEntity<PriceDTO> addPrice(@RequestBody Price price){
        PriceDTO priceDTO = new PriceDTO();
        ResponseEntity<PriceDTO> responseEntity;
        try {
            Price priceReturned = iPriceService.addPrice(price);
            priceDTO.setPrice(priceReturned);
            responseEntity = new ResponseEntity<>(priceDTO, HttpStatus.CREATED);
        } catch (IllegalAccessException ex) {
            ex.printStackTrace();
            priceDTO.setErrorMessage(ex.getMessage());
            responseEntity = new ResponseEntity<>(priceDTO, HttpStatus.NOT_ACCEPTABLE);
        } catch (HibernateException ex) {
            ex.printStackTrace();
            priceDTO.setErrorMessage(ex.getMessage());
            responseEntity = new ResponseEntity<>(priceDTO, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception ex) {
            ex.printStackTrace();
            priceDTO.setErrorMessage(ex.getMessage());
            responseEntity = new ResponseEntity<>(priceDTO, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return responseEntity;
    }

    /**
     * Get list of price of all products
     * @param productIds
     * @return List<Price>
     */
    @PostMapping(value = "/price/getPriceByProductIds")
    public ResponseEntity<List<Price>> getPriceByProductIds(@RequestBody List<Long> productIds){

        List<Price> priceList=null;
        ResponseEntity<List<Price>> responseEntity;
        try {
            priceList = iPriceService.getPriceByProductIds(productIds);
            responseEntity = new ResponseEntity<>(priceList, HttpStatus.OK);
        } catch (IllegalAccessException ex) {
            ex.printStackTrace();
            responseEntity = new ResponseEntity<>(priceList, HttpStatus.NOT_ACCEPTABLE);
        } catch (HibernateException ex) {
            ex.printStackTrace();
            responseEntity = new ResponseEntity<>(priceList, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception ex) {
            ex.printStackTrace();
            responseEntity = new ResponseEntity<>(priceList, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return responseEntity;
    }

    /**
     * Updating the price
     * @param price
     * @param productId
     * @return PriceDTO
     */
    @PutMapping(value = "/price/{product_id}")
    public ResponseEntity<PriceDTO> updatePriceByProductId(@RequestBody Price price,@PathVariable("product_id")Long productId){
        PriceDTO priceDTO = new PriceDTO();
        ResponseEntity<PriceDTO> responseEntity;
        try {
            Price priceReturned = iPriceService.updatePriceByProductId(productId, price);
            priceDTO.setPrice(priceReturned);
            responseEntity = new ResponseEntity<>(priceDTO, HttpStatus.OK);

        } catch (EntityNotFoundException ex) {
            ex.printStackTrace();
            priceDTO.setErrorMessage(ex.getMessage());
            responseEntity = new ResponseEntity<>(priceDTO, HttpStatus.NOT_FOUND);

        } catch (HibernateException ex) {
            ex.printStackTrace();
            priceDTO.setErrorMessage(ex.getMessage());
            responseEntity = new ResponseEntity<>(priceDTO, HttpStatus.INTERNAL_SERVER_ERROR);

        } catch (Exception ex) {

            ex.printStackTrace();
            priceDTO.setErrorMessage(ex.getMessage());
            responseEntity = new ResponseEntity<>(priceDTO, HttpStatus.INTERNAL_SERVER_ERROR);

        }

        return responseEntity;
    }

    /**
     * Deleting the price
     * @param productId
     * @return String
     */
    @DeleteMapping(value = "/price/{product_id}")
    public @ResponseBody ResponseEntity<String> deletePriceByProductId(@PathVariable("product_id")Long productId){
        ResponseEntity<String> responseEntity;
        PriceDTO priceDTO = new PriceDTO();
        try {
            iPriceService.deletePriceByProductId(productId);
            responseEntity = new ResponseEntity<>("{\"message\" : \"Deleted Successfully\"}", HttpStatus.OK);

        } catch (EntityNotFoundException ex) {
            ex.printStackTrace();
            priceDTO.setErrorMessage(ex.getMessage());
            responseEntity = new ResponseEntity<>("{\"message\" : \"Not Found\"}", HttpStatus.NOT_FOUND);

        } catch (HibernateException ex) {
            ex.printStackTrace();
            priceDTO.setErrorMessage(ex.getMessage());
            responseEntity = new ResponseEntity<>("{\"message\" : \"Data related error encountered\"}", HttpStatus.INTERNAL_SERVER_ERROR);

        } catch (Exception ex) {
            ex.printStackTrace();
            priceDTO.setErrorMessage(ex.getMessage());
            responseEntity = new ResponseEntity<>("Cannot Delete because id is referential", HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }
}
