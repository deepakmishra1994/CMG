package com.meru.priceservice.controller;

public class PriceController {
}
