insert into price (product_id,price,currency) values(1001,200,'INR');
insert into price (product_id,price,currency) values(1002,400,'EUR');
insert into price (product_id,price,currency) values(1003,20,'USD');
insert into price (product_id,price,currency) values(1004,4000,'INR');
insert into price (product_id,price,currency) values(1005,50,'USD');