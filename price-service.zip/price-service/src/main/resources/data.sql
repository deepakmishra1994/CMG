insert into price (product_id,price,currency) values(1,200,"INR");
insert into price (product_id,price,currency) values(2,400,"EUR");
insert into price (product_id,price,currency) values(3,20,"USD");