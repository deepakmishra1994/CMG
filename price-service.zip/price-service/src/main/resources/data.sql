insert into price (product_id,price,currency) values(1001,200,"INR");
insert into price (product_id,price,currency) values(1002,400,"EUR");
insert into price (product_id,price,currency) values(1003,20,"USD");