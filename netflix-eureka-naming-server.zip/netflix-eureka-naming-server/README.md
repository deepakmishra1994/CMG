# netflix-eureka-naming-server

Eureka naming server for meru service registry