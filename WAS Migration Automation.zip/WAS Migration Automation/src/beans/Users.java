package beans;
public class Users 
{    
    private int id;
    private String userName;
    private String password;
    private String IBMusername;
    private String IBMpassword;
    private String automationLevel;
    private String folderPath;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

	public String getIBMusername() {
		return IBMusername;
	}

	public void setIBMusername(String iBMusername) {
		IBMusername = iBMusername;
	}

	public String getIBMpassword() {
		return IBMpassword;
	}

	public void setIBMpassword(String iBMpassword) {
		IBMpassword = iBMpassword;
	}

	public String getAutomationLevel() {
		return automationLevel;
	}

	public void setAutomationLevel(String automationLevel) {
		this.automationLevel = automationLevel;
	}

	public String getFolderPath() {
		return folderPath;
	}

	public void setFolderPath(String folderPath) {
		this.folderPath = folderPath;
	}
       
}