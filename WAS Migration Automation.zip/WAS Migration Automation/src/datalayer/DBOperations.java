package datalayer;
import java.sql.*;
public class DBOperations 
{
		private static Connection con=null;
		public static Connection getConnection()
	    {
	        if(con==null)
	        {
	            try
	            {
	            	Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
	                con=DriverManager.getConnection("jdbc:sqlserver://ASHU\\DMSERVER:64924;database=WAS;userName=sa;password=dm");	                	                
	             }
	            catch(Exception ex)
	            {
	            	ex.printStackTrace();
	            }
	        
	        }
	        return con;	        
	    }
}

