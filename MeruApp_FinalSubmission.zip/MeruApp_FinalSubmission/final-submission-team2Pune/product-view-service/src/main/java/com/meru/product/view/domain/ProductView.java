package com.meru.product.view.domain;

public class ProductView {
	
	private Long productId;
	private String productName;
	private String productDescription;
	private String orignalPrice;
	private Double discountPercentage;
	private String discountedPrice;
	private String inStock;
	private String promoCode;
	private String offerExpiryIn;
	private String message;
	private Boolean status;
	private String port;
	
	public Double getDiscountPercentage() {
		return discountPercentage;
	}
	public void setDiscountPercentage(Double discountPercentage) {
		this.discountPercentage = discountPercentage;
	}
	public Long getProductId() {
		return productId;
	}
	public void setProductId(Long productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public String getOrignalPrice() {
		return orignalPrice;
	}
	public void setOrignalPrice(String orignalPrice) {
		this.orignalPrice = orignalPrice;
	}
	public String getDiscountedPrice() {
		return discountedPrice;
	}
	public void setDiscountedPrice(String discountedPrice) {
		this.discountedPrice = discountedPrice;
	}
	public String getInStock() {
		return inStock;
	}
	public void setInStock(String inStock) {
		this.inStock = inStock;
	}
	public String getPromoCode() {
		return promoCode;
	}
	public void setPromoCode(String promoCode) {
		this.promoCode = promoCode;
	}
	public String getOfferExpiryIn() {
		return offerExpiryIn;
	}
	public void setOfferExpiryIn(String offerExpiryIn) {
		this.offerExpiryIn = offerExpiryIn;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Boolean getStatus() {
		return status;
	}
	public void setStatus(Boolean status) {
		this.status = status;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	@Override
	public String toString() {
		return "ProductView{" +
				"productId=" + productId +
				", productName='" + productName + '\'' +
				", productDescription='" + productDescription + '\'' +
				", orignalPrice='" + orignalPrice + '\'' +
				", discountPercentage=" + discountPercentage +
				", discountedPrice='" + discountedPrice + '\'' +
				", inStock='" + inStock + '\'' +
				", promoCode='" + promoCode + '\'' +
				", offerExpiryIn='" + offerExpiryIn + '\'' +
				", message='" + message + '\'' +
				", status=" + status +
				", port='" + port + '\'' +
				'}';
	}
}
