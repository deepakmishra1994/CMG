package com.meru.product.view.adapter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.meru.product.view.domain.Product;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
public class ProductAdapter {

	@Autowired 
	RestTemplate restTemplate;

	@HystrixCommand(fallbackMethod = "productServiceDown")
	public Product getProductById(Long productId, String serviceUrl) {
		Product resp = new Product();
		StringBuilder url = new StringBuilder(serviceUrl);
		url.append("/product/product/{id}");
		Map<String, Long> uriMap = new HashMap<>();
		uriMap.put("id", productId);

		System.out.println("Calling :: " + url.toString());
		ResponseEntity<Product> prod = restTemplate.getForEntity(url.toString(), Product.class, uriMap);
		if(prod != null && prod.getBody()!= null) {
			resp = prod.getBody();
		}else {
			resp.setFetchMessage("No Product Found");
		}
		return resp;
	}

	public Product productServiceDown(Long productId, String serviceUrl) {
		Product response = new Product();
		response.setFetchMessage("Unabe To Call " + serviceUrl);
		return response;
	}

	public List<Product> getAllProducts(String serviceUrl) {
		List<Product> response = null;
		StringBuilder url = new StringBuilder(serviceUrl);
		url.append("/product/product/getAll");
		try {
			System.out.println("Calling :: " + url.toString());
			ResponseEntity<List<Product>> productResponse = restTemplate.exchange(url.toString(), HttpMethod.GET, null, new ParameterizedTypeReference<List<Product>>() {});
			if(productResponse != null && productResponse.getBody() != null) {
				response = productResponse.getBody();
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return response;
	}

}
