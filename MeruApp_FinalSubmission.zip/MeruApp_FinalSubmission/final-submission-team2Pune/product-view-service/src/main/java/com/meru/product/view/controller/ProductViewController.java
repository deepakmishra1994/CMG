package com.meru.product.view.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.meru.product.view.domain.ProductView;
import com.meru.product.view.service.ProductViewService;

@RestController
public class ProductViewController {
	
	@Autowired
	private ProductViewService productViewService;

	@RequestMapping(value = "/")
	public String test() {
		return "<center><h2>Welcome To Product View</h2></center>";
	}
	
	@RequestMapping(value = "/getProductById", method = RequestMethod.GET)
	public ResponseEntity<ProductView> getProductById(@RequestParam Long productId){
		return productViewService.getProductByProductId(productId);
	}
	
	@RequestMapping(value = "/getAllProducts", method = RequestMethod.GET)
	public ResponseEntity<List<ProductView>> getAllProducts(){
		return productViewService.getAllProducts();
	}
	
}
