package com.meru.product.view.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.EurekaClient;
import com.netflix.discovery.shared.Application;

import com.meru.product.view.adapter.InventoryAdapter;
import com.meru.product.view.adapter.PriceAdapter;
import com.meru.product.view.adapter.ProductAdapter;
import com.meru.product.view.adapter.PromotionAdapter;
import com.meru.product.view.domain.Inventory;
import com.meru.product.view.domain.PriceDTO;
import com.meru.product.view.domain.Product;
import com.meru.product.view.domain.ProductView;
import com.meru.product.view.domain.PromotionResponse;
import com.meru.product.view.util.ServiceNames;

@Service
public class ProductViewService {

	@Autowired
	PromotionAdapter promotionAdapter;

	@Autowired
	ProductAdapter productAdapter;

	@Autowired
	PriceAdapter priceAdapter;

	@Autowired
	private InventoryAdapter inventoryAdapter;

	@Autowired
	EurekaClient eurekaClient;

	public ResponseEntity<ProductView> getProductByProductId(Long productId){
		ResponseEntity<ProductView> response = null;
		ProductView resp = new ProductView();
		try {
			Product product = productAdapter.getProductById(productId, "http://MERUAPIGATEWAY");
			if(product == null || product.getProductId() == null) {
				System.out.println(product.getFetchMessage());
				resp.setMessage(product.getFetchMessage());
				response = new ResponseEntity<>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
			}else {
				PriceDTO price = priceAdapter.getPriceByProductId(productId, "http://"+ServiceNames.PRICE_SERVICE);
				PromotionResponse promo = promotionAdapter.getPromotionByProductId(productId, "http://"+ServiceNames.PROMOTION_SERVICE);
				Inventory inventory = inventoryAdapter.getInventoryByProductId(productId, "http://MERUAPIGATEWAY");
				resp = mapProductViewResponse(product, price, promo, inventory);
				response = new ResponseEntity<>(resp, HttpStatus.OK);
			}
		}catch(Exception e) {
			e.printStackTrace();
			resp.setStatus(false);
			resp.setMessage(e.toString());
			response = new ResponseEntity<>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	public ResponseEntity<List<ProductView>> getAllProducts() {
		ResponseEntity<List<ProductView>> response = null;
		List<ProductView> resp = new ArrayList();
		try {
			List<Product> productList =productAdapter.getAllProducts("http://MERUAPIGATEWAY");
			if(productList != null && productList.size() >0) {
				List<Long> productIdList = new ArrayList();
				productList.forEach(pr -> productIdList.add(pr.getProductId()));
				Map<Long, PriceDTO> priceMap = getPriceMap(productIdList);
				if(priceMap != null && !priceMap.isEmpty()) {
					Map<Long, Inventory> inventoryMap = getInventoryMap(productIdList);
					Map<Long, PromotionResponse> promotionMap = getPromotionMap(productIdList);
					response = mapProductViewResponse(productList, priceMap, inventoryMap, promotionMap);
				}else {
					productList.forEach(prd -> resp.add(mapProductViewResponse(prd, null, null, null)));
				}
			}else {
				throw new RuntimeException("No Products Fetched");
			}
		}catch(Exception e) {
			ProductView prdct = new ProductView();
			prdct.setStatus(false);
			prdct.setMessage("Unable To Fetch Products !!");
			resp.add(prdct);
			e.printStackTrace();
			response = new ResponseEntity<>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	private ResponseEntity<List<ProductView>> mapProductViewResponse(List<Product> productList, Map<Long, PriceDTO> priceMap, Map<Long, Inventory> inventoryMap, Map<Long, PromotionResponse> promotionMap) {
		ResponseEntity<List<ProductView>> response = null;
		List<ProductView> resp = new ArrayList<ProductView>();
		try {
			productList.forEach(prd -> {
				resp.add(mapProductViewResponse(prd, priceMap.get(prd.getProductId()), promotionMap.get(prd.getProductId()), inventoryMap.get(prd.getProductId())));
			});
			response = new ResponseEntity<List<ProductView>>(resp, HttpStatus.OK);
		}catch(Exception e) {
			ProductView prdct = new ProductView();
			prdct.setStatus(false);
			prdct.setMessage("Unable To Fetch Products !!");
			resp.add(prdct);
			e.printStackTrace();
			response = new ResponseEntity<>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	private Map<Long, PromotionResponse> getPromotionMap(List<Long> productIdList) {
		Map<Long, PromotionResponse> promotionMap = new HashMap<>();
		List<PromotionResponse> promotionList = promotionAdapter.getPromotionByProductIdList(productIdList, "http://"+ServiceNames.PROMOTION_SERVICE);
		if(promotionList.size() > 0) {
			promotionList.forEach(resp -> {
				if(resp != null) {
					promotionMap.put(resp.getProductId(), resp);
				}
			});
		}
		return promotionMap;
	}

	private Map<Long, Inventory> getInventoryMap(List<Long> productIdList) {
		Map<Long, Inventory> inventoryMap = new HashMap<>();
		List<Inventory> inventoryList = inventoryAdapter.getInventoryByProductIdList(productIdList, "http://MERUAPIGATEWAY");
		if(inventoryList.size() > 0) {
			inventoryList.forEach(resp -> {
				if(resp != null) {
					inventoryMap.put(resp.getPid(), resp);
				}
			});
		}
		return inventoryMap;
	}

	private Map<Long, PriceDTO> getPriceMap(List<Long> productIdList) {
		Map<Long, PriceDTO> priceMap = new HashMap<>();
		List<PriceDTO> response = priceAdapter.getPriceByProcutIdList(productIdList, "http://"+ServiceNames.PRICE_SERVICE);
		if(response.size() > 0) {
			response.forEach(resp -> {
				if(resp.getPrice() != null) {
					priceMap.put(resp.getPrice().getProductId(), resp);
				}
			});	
		}
		return priceMap;
	}

	private ProductView mapProductViewResponse(Product product, PriceDTO price, PromotionResponse promo, Inventory inventory) {
		ProductView response = new ProductView();
		//Set Properties From Product
		response.setProductId(product.getProductId());
		if(product.getProductName()!= null && !product.getProductName().isEmpty()) {
			response.setProductName(product.getProductName());
		}
		if(product.getDescription()!= null && !product.getDescription().isEmpty()) {
			response.setProductDescription(product.getDescription());
		}
		//Set Price From Price DTO and Discount Info
		if(price != null && price.getPrice()!= null && price.getPrice().getPrice() != null && promo!=null) {
			response.setOrignalPrice(price.getPrice().getPrice().toString());
			response.setPort(price.getPort());
			if(promo.getStatus()!= null && promo.getStatus() && promo.getDiscountPercentage() != null) {
				response.setDiscountPercentage(promo.getDiscountPercentage());
				Double discountedPrice = price.getPrice().getPrice() - (promo.getDiscountPercentage()/100 * price.getPrice().getPrice());
				response.setDiscountedPrice(discountedPrice.toString());
				response.setOfferExpiryIn(promo.getOfferExipryIn());
				response.setPromoCode(promo.getPromoCode());
			}else {
				response.setDiscountPercentage(0.0d);
				response.setDiscountedPrice("NA");
				response.setPromoCode("NA");
				response.setOfferExpiryIn("NA");
			}
		}else {
			response.setOrignalPrice("No Price Set");
			response.setDiscountPercentage(0.0d);
			response.setDiscountedPrice("NA");
			response.setPromoCode("NA");
			response.setOfferExpiryIn("NA");
			response.setMessage("Product Details Needs to Be Updated In Respective Services");
		}
		if(inventory!=null && inventory.getCountInStock() != 0) {
			response.setInStock(String.valueOf(inventory.getCountInStock()));
		}
		System.out.println(response.toString());
		return response;
	}

	public String getUrlByServiceName(String appName) {
		StringBuilder response = new StringBuilder();
		Application app = eurekaClient.getApplication(appName);
		InstanceInfo instance = app.getInstances().get(0);
		response.append(instance.getHomePageUrl());
		return response.toString();
	}

}
