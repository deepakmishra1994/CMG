package com.meru.product.view.adapter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.meru.product.view.domain.PromotionResponse;

import org.springframework.stereotype.Service;

@Service
public class PromotionAdapter {

	@Autowired
	RestTemplate restTemplate;

	public PromotionResponse getPromotionByProductId(Long productId, String serviceUrl) {
		StringBuilder url = new StringBuilder(serviceUrl);
		url.append("/promotion/getPromotionByProductId?productId={productId}");
		Map<String , Long> uriVariables = new HashMap<>();
		System.out.println("Calling :: " + url.toString());
		uriVariables.put("productId", productId);
		PromotionResponse response = null;
		try {
			ResponseEntity<PromotionResponse> resp = restTemplate.getForEntity(url.toString(), PromotionResponse.class, uriVariables);
			if(resp != null && resp.getBody() != null && resp.getBody().getStatus()) {
				response = resp.getBody();
				System.out.println(resp.getBody().getMessage());
			}else {
				response = new PromotionResponse();
				response.setStatus(false);
			}
		}catch(Exception e) {
			response = new PromotionResponse();
			response.setStatus(false);
		}
		return response;
	}

	public List<PromotionResponse> getPromotionByProductIdList(List<Long> productIdList, String serviceUrl) {
		List<PromotionResponse> response = null;
		StringBuilder url = new StringBuilder(serviceUrl);
		url.append("/promotion/getAllPromotions");
		try {
			System.out.println("Calling :: " + url.toString());
			ResponseEntity<List<PromotionResponse>> promotionResp = restTemplate.exchange(url.toString(), HttpMethod.GET, null, new ParameterizedTypeReference<List<PromotionResponse>>() {});
			if(promotionResp != null && promotionResp.getBody() != null) {
				response = promotionResp.getBody();
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return response;
	}
	
	
}
