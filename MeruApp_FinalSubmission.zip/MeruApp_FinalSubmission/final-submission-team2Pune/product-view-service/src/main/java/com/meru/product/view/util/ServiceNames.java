package com.meru.product.view.util;

public class ServiceNames {
	public final static String PRICE_SERVICE = "price-service";
	public final static String PROMOTION_SERVICE = "promotion-service";
	public final static String INVENTORY_SERVICE = "inventory-service";
	public final static String PRODUCT_SERVICE = "product-service";
}
