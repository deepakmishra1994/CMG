package com.meru.product.view.adapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.meru.product.view.domain.Price;
import com.meru.product.view.domain.PriceDTO;

@Service
public class PriceAdapter {
	
	@Autowired
	private RestTemplate restTemplate;

	public PriceDTO getPriceByProductId(Long productId, String serviceUrl) {
		StringBuilder url = new StringBuilder(serviceUrl);
		url.append("/price/{product_id}");
		Map<String , Long> uriVariables = new HashMap<>();
		uriVariables.put("product_id", productId);
		PriceDTO response = null;
		try {
			System.out.println("Calling :: " + url.toString());
			ResponseEntity<PriceDTO> price = restTemplate.getForEntity(url.toString(), PriceDTO.class, uriVariables);
			if(price != null && price.getBody() != null) {
				response = price.getBody();
			}else {
				response = new PriceDTO();
				response.setErrorMessage("Unable To Fetch Price");
			}
		}catch(Exception e) {
			response = new PriceDTO();
			response.setErrorMessage("Unable To Fetch Price");
		}
		return response;
	}

	public List<PriceDTO> getPriceByProcutIdList(List<Long> productIdList, String serviceUrl) {
		List<PriceDTO> response = new ArrayList();
		StringBuilder url = new StringBuilder(serviceUrl);
		url.append("/price/getPriceByProductIds");
		try {
			System.out.println("Calling :: " + url.toString());
			//ResponseEntity<List<PriceDTO>> priceResponse = restTemplate.postForObject(url.toString(), productIdList, ResponseEntity.class);
			HttpEntity<List<Long>> httpEntity = new HttpEntity<List<Long>>(productIdList);
			ResponseEntity<List<Price>> priceResponse = restTemplate.exchange(url.toString(),HttpMethod.POST, httpEntity, new ParameterizedTypeReference<List<Price>>() {});
			if(priceResponse != null && priceResponse.getBody() != null && priceResponse.getBody().size() > 0 ) {
				priceResponse.getBody().forEach(pResponse -> {
					PriceDTO dto = new PriceDTO();
					dto.setPrice(pResponse);
					response.add(dto);
				});
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return response;
	}

}
