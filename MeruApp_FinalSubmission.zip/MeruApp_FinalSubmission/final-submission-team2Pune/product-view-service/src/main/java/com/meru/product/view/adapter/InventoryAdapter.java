package com.meru.product.view.adapter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.meru.product.view.domain.Inventory;

@Service
public class InventoryAdapter {
	
	@Autowired
	private RestTemplate restTemplate;

	public Inventory getInventoryByProductId(Long productId, String serviceUrl) {
		StringBuilder url = new StringBuilder(serviceUrl);
		url.append("/inventory/inventory/products/{productId}");
		Map<String , Long> uriVariables = new HashMap<>();
		uriVariables.put("productId", productId);
		Inventory response = null;
		try {
			ResponseEntity<Inventory> inventory = restTemplate.getForEntity(url.toString(), Inventory.class, uriVariables);
			if(inventory != null && inventory.getBody() != null) {
				response = inventory.getBody();
			}else {
				response = new Inventory();
			}
		}catch(Exception e) {
			response = new Inventory();
		}
		return response;
	}

	public List<Inventory> getInventoryByProductIdList(List<Long> productIdList, String serviceUrl) {
		List<Inventory> response = null;
		StringBuilder url = new StringBuilder(serviceUrl);
		url.append("/inventory/inventory/products");
		try {
			System.out.println("Calling :: " + url.toString());
			ResponseEntity<List<Inventory>> inventoryResp = restTemplate.exchange(url.toString(), HttpMethod.GET, null, new ParameterizedTypeReference<List<Inventory>>() {});
			if(inventoryResp != null && inventoryResp.getBody() != null) {
				response = inventoryResp.getBody();
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return response;
	}

}
