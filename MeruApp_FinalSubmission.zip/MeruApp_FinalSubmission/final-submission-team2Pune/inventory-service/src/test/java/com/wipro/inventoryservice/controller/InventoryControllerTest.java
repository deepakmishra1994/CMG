package com.wipro.inventoryservice.controller;

import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.List;

import org.hamcrest.core.IsEqual;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.JsonPathResultMatchers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.wipro.inventoryservice.entity.Inventory;
import com.wipro.inventoryservice.service.InventoryService;

@RunWith(SpringRunner.class)
@WebMvcTest(InventoryController.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class InventoryControllerTest {

	@Autowired
	private MockMvc mvc;
	@MockBean
	private InventoryService service;

	Inventory iv = new Inventory(101,101l,10,20);
	List<Inventory> listOfiv = Arrays.asList(iv);
	@Before
	public void setUp() {
	
	Mockito.when(service.findAll())
	 .thenReturn(listOfiv);
	}
	
	@Test
	public void testGetAllProducts() throws Exception {
		

		mvc.perform(get("/inventory-service/products")
				.contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				.andExpect((ResultMatcher) jsonPath(("$, hasSize(1)")))
				.andExpect((ResultMatcher) jsonPath("$[0].pid", (iv.getPid())));

	}


/*	@Test
	public void testGetProductsById() throws Exception {
		

		mvc.perform(get("/inventory-service/getProductsById/{pid}")
				.contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				.andExpect((ResultMatcher) jsonPath("$.pid", (iv.getPid())));

	}
	
	@Test
	public void testAddProduct() throws Exception {
		

		mvc.perform(post("/inventory-service/createProducts")
				.content(asJsonString(new Inventory(102, "Gloves", "Small", 10, 20, 35, 40, "PQR")))
				.contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				.andExpect((ResultMatcher) jsonPath("$.pid", (iv.getPid())));

	}*/
	
	

}