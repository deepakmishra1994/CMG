package com.wipro.inventoryservice.dao;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringRunner;

import com.wipro.inventoryservice.entity.Inventory;

@RunWith(SpringRunner.class)
@DataJpaTest
public class InventoryRepositoryTest {

	@Autowired
	private TestEntityManager entityManager;
	
	@Autowired
	private InventoryRepository inventoryRepository;
	
	@Test
	public void testFindByName() {
		// Input / Define
		Inventory iv = new Inventory(101,101l,10,20);
		entityManager.persist(iv);
		entityManager.flush();
		
		// Execute / Process
		Inventory found = inventoryRepository.findByPid(iv.getPid());
		
		// Validate / Output
		assertTrue(101 == found.getPid());
	}

}
