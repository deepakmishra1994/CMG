package com.wipro.inventoryservice.service;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit4.SpringRunner;

import com.wipro.inventoryservice.dao.InventoryRepository;
import com.wipro.inventoryservice.entity.Inventory;
@RunWith(SpringRunner.class)
public class InventoryServiceImplTest {
	@Autowired
	private InventoryService inventoryService;
	@MockBean
	private static InventoryRepository inventoryRepository;
	
	@TestConfiguration
	static class InventoryServiceImplTestContextConfiguration{
		@Bean 
		public InventoryService inventoryService() {
			return new InventoryServiceImpl(inventoryRepository);
		}
	}
	
	
	Inventory iv = new Inventory(101,101l,10,20);
	
	@Before
	public void setUp() {
	
	Mockito.when(inventoryRepository.findByPid(iv.getPid()))
	.thenReturn(iv);
	//.thenReturn(101);
	}
	
	@Test
	public void testFindByName() {
		Inventory found = inventoryService.findByPid((long) 101);
		assertTrue(101 == found.getPid());
	}

}
