package com.wipro.inventoryservice.service;


import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.wipro.inventoryservice.dao.InventoryRepository;
import com.wipro.inventoryservice.entity.Inventory;

@Service
public class InventoryServiceImpl implements InventoryService {

	
	private InventoryRepository inventoryRepository;
	
	@Autowired
	public InventoryServiceImpl(InventoryRepository theInventoryRepository) {
		inventoryRepository = theInventoryRepository;
	}

	@Override
	public List<Inventory> findAll() {
		// TODO Auto-generated method stub
		return inventoryRepository.findAll();
		
	}

	@Override
	public Inventory findByPid(Long pid) {
		// TODO Auto-generated method stub
		//Inventory theInventory =  inventoryRepository.findOne(pid);	
		Inventory theInventory =  inventoryRepository.findByPid(pid);
		return theInventory;
	}

		
	@Override
	public void save(Inventory theInventory) {
		// TODO Auto-generated method stub
		inventoryRepository.save(theInventory);
	}

	@Override
	public void deleteByPid(Inventory theInventory) {
		// TODO Auto-generated method stub
		
		inventoryRepository.delete(theInventory);
	}

	@Override
	public ResponseEntity<String> addProduct(Long productId) {
		ResponseEntity<String> resp = null;
		StringBuilder response = new StringBuilder();
		Inventory invent = new Inventory();
		invent.setPid(productId);
		try {
			Inventory savedEntity = inventoryRepository.save(invent);
			if(savedEntity == null) {
				response.append("Failed To Save");
				resp = new ResponseEntity<String>(response.toString(), HttpStatus.NO_CONTENT);
			}else {
				response.append("Save Successful");
				resp = new ResponseEntity<String>(response.toString(), HttpStatus.OK);
			}
		}catch(DataIntegrityViolationException ex) {
			response.append("Product Alreay Exists");
			resp = new ResponseEntity<String>(response.toString(), HttpStatus.FORBIDDEN);
		}catch(Exception e) {
			response.append("Failed To Save");
			resp = new ResponseEntity<String>(response.toString(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return resp;
		
	}

	/*@Override
	public void deleteByPid(int pid) {
		// TODO Auto-generated method stub;
		inventoryRepository.deleteByPid(pid);
	}*/

	
	
}
