package com.wipro.inventoryservice.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.wipro.inventoryservice.entity.Inventory;

public interface InventoryRepository extends JpaRepository<Inventory, Integer>  {

	public Inventory findByPid(Long pid);
	public void deleteByPid(Inventory theinventory);
}
