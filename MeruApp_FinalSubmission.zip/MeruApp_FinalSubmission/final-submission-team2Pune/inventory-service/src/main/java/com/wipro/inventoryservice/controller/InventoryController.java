package com.wipro.inventoryservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.inventoryservice.entity.Inventory;
import com.wipro.inventoryservice.service.InventoryService;

@RestController
@RequestMapping("/inventory")
public class InventoryController {

	private InventoryService inventoryService;

	@Autowired
	public InventoryController(InventoryService theinventoryService) {
		inventoryService = theinventoryService;
	}

	@Value("${message: Hello Default}")
	private String message;
	
	
	@GetMapping("/message")
	public String getMessage() {
		return this.message;
	}
	
	@GetMapping("/products")
	public List<Inventory> findAll() {
		return inventoryService.findAll();
	}


	@GetMapping("/products/{pid}")
	public Inventory getProduct(@PathVariable Long pid) {

		Inventory theInventory = inventoryService.findByPid(pid);

		if (theInventory == null) {
			throw new RuntimeException("Product id not found - " + pid);
		}

		return theInventory;
	}
	
	@RequestMapping(value= "/addProduct", method = RequestMethod.POST)
	public ResponseEntity<String> addProductToInventory(@RequestBody Long productId) {
		return inventoryService.addProduct(productId);
	}
	
	
	
	@PostMapping("/createProducts")
	public Inventory addProduct(@RequestBody Inventory theInventory) {

		inventoryService.save(theInventory);

		return theInventory;
	}

	@PutMapping("/updateProducts")
	public Inventory updateInventory(@RequestBody Inventory theInventory) {

		inventoryService.save(theInventory);

		return theInventory;
	}

	@DeleteMapping("/products/{pid}")
	public String deleteProducts(@PathVariable Long pid) {

		Inventory tempInventory = inventoryService.findByPid(pid);
		System.out.println("**********"+tempInventory+"**********************");

		// throw exception if null

		if (tempInventory == null) {
			throw new RuntimeException("Product id not found - " + pid);
		}

		inventoryService.deleteByPid(tempInventory);

		return "Deleted product id - " + pid;
	}








}
