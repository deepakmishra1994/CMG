package com.wipro.inventoryservice.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="inventory")
public class Inventory {

	public Inventory() {
		
	}
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	int id;
	
	@Column(name="product_id", unique = true)
	Long pid;
	
	@Column(name="count_instock")
	int countInStock;
	
	@Column(name="count_sold")
	int countSold;


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Long getPid() {
		return pid;
	}

	public void setPid(Long pid) {
		this.pid = pid;
	}

	public int getCountInStock() {
		return countInStock;
	}

	public void setCountInStock(int countInStock) {
		this.countInStock = countInStock;
	}

	public int getCountSold() {
		return countSold;
	}

	public void setCountSold(int countSold) {
		this.countSold = countSold;
	}


	public Inventory(int id, Long pid, int countInStock, int countSold) {
		super();
		this.id = id;
		this.pid = pid;
		this.countInStock = countInStock;
		this.countSold = countSold;
	}

	@Override
	public String toString() {
		return "Inventory [id=" + id + ", pid=" + pid + ", countInStock=" + countInStock + ", countSold=" + countSold
				+ "]";
	}



	
}