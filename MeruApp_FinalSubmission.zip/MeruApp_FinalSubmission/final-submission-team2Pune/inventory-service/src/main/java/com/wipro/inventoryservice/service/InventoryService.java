package com.wipro.inventoryservice.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.wipro.inventoryservice.entity.Inventory;

public interface InventoryService {
	
	public List<Inventory> findAll();
	
	public Inventory findByPid(Long pid);
	
	public void save(Inventory theInventory);
	
	public void deleteByPid(Inventory theInventory);

	public ResponseEntity<String> addProduct(Long productId);


}
