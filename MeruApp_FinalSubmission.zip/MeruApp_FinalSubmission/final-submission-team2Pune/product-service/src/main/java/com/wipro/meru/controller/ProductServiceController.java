package com.wipro.meru.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.meru.entity.Product;
import com.wipro.meru.service.ProductServiceImpl;

@RestController
@RequestMapping("/product")
public class ProductServiceController extends BaseController {

	private static final Logger logger = LoggerFactory.getLogger(ProductServiceController.class);

	@Autowired
	ProductServiceImpl productService;

	@GetMapping("/getAll")
	public ResponseEntity<List<Product>> getAllProducts() {
		ResponseEntity<List<Product>> returnValue = null;
		try {
			logger.info("ProductServiceController :: Entered getProducts ");
			returnValue = success(productService.getAllProducts());
		} catch (Exception ex) {
			logger.error("ProductServiceController :: getProducts" + ex.getMessage());
			ex.printStackTrace();
			returnValue = failed();
		}
		return returnValue;
	}

	@PostMapping("/add")
	public void addProduct(@RequestBody Product prd) {
		productService.addProduct(prd);
	}
	
	@PutMapping("/update")
	public ResponseEntity<Product> updateProduct(@RequestBody Product prd) {
		ResponseEntity<Product> returnValue = null;		
		try {
		Product updatedProd = productService.updateProduct(prd);
		returnValue = success(updatedProd);
		} catch (Exception ex) {
			logger.error("ProductServiceController :: getProducts" + ex.getMessage());
			ex.printStackTrace();
			returnValue = failed();
		}
		return returnValue;
	}

	@GetMapping("/{id}")
	public ResponseEntity<Product> getProductById(@PathVariable(required = true) long id) {
		ResponseEntity<Product> returnValue = null;	
		try {
			logger.info("ProductServiceController :: Entered getProductById ");
			returnValue = success(productService.getProductById(id));
		} catch (Exception ex) {
			logger.error("ProductServiceController :: getProductById" + ex.getMessage());
			ex.printStackTrace();
			returnValue = failed();
		}
		return returnValue;
	}

	@DeleteMapping("/{id}")
	public void deleteProduct(@PathVariable(required = true) long id) {
		productService.deleteProduct(id);
	}

}
