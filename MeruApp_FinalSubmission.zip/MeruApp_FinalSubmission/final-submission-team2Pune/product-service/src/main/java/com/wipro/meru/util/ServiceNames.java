package com.wipro.meru.util;

public class ServiceNames {

	public final static String PRICE_SERVICE = "price-service";
	public final static String PROMOTION_SERVICE = "promotion-service";
	public final static String INVENTORY_SERVICE = "inventory-service";
}
