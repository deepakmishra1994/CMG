package com.wipro.meru.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class BaseController {
	public <T> ResponseEntity<T> success(T result) {
		return new ResponseEntity<>(result, HttpStatus.OK);
	}
	public <T> ResponseEntity<T> failed(){
		return new ResponseEntity<>(null,HttpStatus.EXPECTATION_FAILED); 
		
	}
}
