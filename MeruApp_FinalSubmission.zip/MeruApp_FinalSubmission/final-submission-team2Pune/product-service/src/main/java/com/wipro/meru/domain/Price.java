package com.wipro.meru.domain;

public class Price {

    private Long priceId;
    private Long productId;
    private Long price;
    private String currency;

    public Price(){
    }

    public Price(Long priceId, Long productId, Long price, String currency) {
        this.priceId = priceId;
        this.productId = productId;
        this.price = price;
        this.currency = currency;
    }

    public Long getPriceId() {
        return priceId;
    }

    public void setPriceId(Long priceId) {
        this.priceId = priceId;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public Long getPrice() {
        return price;
    }

    public void setPrice(Long price) {
        this.price = price;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    @Override
    public String toString() {
        return "Price{" +
                "priceId=" + priceId +
                ", productId=" + productId +
                ", price=" + price +
                ", currency='" + currency + '\'' +
                '}';
    }

}
