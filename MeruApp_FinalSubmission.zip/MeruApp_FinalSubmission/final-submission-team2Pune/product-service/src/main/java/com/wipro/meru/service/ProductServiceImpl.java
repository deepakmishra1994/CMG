package com.wipro.meru.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.EurekaClient;
import com.netflix.discovery.shared.Application;
import com.wipro.meru.domain.PriceDTO;
import com.wipro.meru.domain.PromotionResponse;
import com.wipro.meru.entity.Product;
import com.wipro.meru.repository.ProductDao;
import com.wipro.meru.util.ServiceNames;

@Service
public class ProductServiceImpl implements ProductService{

	@Autowired
    ProductDao productDao;

	@Autowired
	RestTemplate restTemplate;
	
	@Autowired
	private EurekaClient eurekaClient;
	
	@Override
    public List<Product> getAllProducts() {
        return productDao.findAll();
    }

	@Override
    public Product addProduct(Product product) {
		Product returnedProduct = productDao.save(product);
		if(returnedProduct != null) {
			//Update Product in Price
			try {
				addProductInPrice(returnedProduct);
				addProductInInventory(returnedProduct);
				addProductToPromotion(returnedProduct);
			}catch(Exception e) {
				e.printStackTrace();
				returnedProduct = new Product();
			}
		}
        return returnedProduct;
    }
    
	private void addProductToPromotion(Product product) {
		StringBuilder promotionServiceUrl = new StringBuilder();
		promotionServiceUrl.append(getUrlByServiceName(ServiceNames.PROMOTION_SERVICE));
		promotionServiceUrl.append("promotion/addProduct");
		ResponseEntity<PromotionResponse> response = restTemplate.postForEntity(promotionServiceUrl.toString(), product.getProductId(), PromotionResponse.class);
		if(response != null && response.getBody() != null  && response.getBody().getStatus()) {
			System.out.println("Product Saved In Promotion Sucessfully");
			System.out.println(response.getBody().getMessage());
		}else {
			System.out.println(response.getBody().getMessage());
			System.out.println("Error Saving Product In Promotion");
		}
		
	}

	private void addProductInPrice(Product product) {
		StringBuilder priceServiceUrl = new StringBuilder();
		priceServiceUrl.append(getUrlByServiceName(ServiceNames.PRICE_SERVICE));
		priceServiceUrl.append("/price/addProduct");
		System.out.println("Calling :: "+priceServiceUrl);
		ResponseEntity<PriceDTO> response = restTemplate.postForEntity(priceServiceUrl.toString(), product.getProductId(), PriceDTO.class);
		if(response != null && response.getBody() != null  && response.getBody().getErrorMessage().contains("Saved")) {
			System.out.println("Product Saved In Price Sucessfully");
		}else {
			System.out.println("Error Saving Product In Price");
		}
	}
	
	private void addProductInInventory(Product product) {
		StringBuilder inventoryServiceUrl = new StringBuilder();
		inventoryServiceUrl.append(getUrlByServiceName(ServiceNames.INVENTORY_SERVICE));
		inventoryServiceUrl.append("/inventory/addProduct");
		ResponseEntity<String> response = restTemplate.postForEntity(inventoryServiceUrl.toString(), product.getProductId(), String.class);
		if(response != null && !response.getBody().isEmpty()  && response.getBody().contains("Successful")) {
			System.out.println("Product Saved In Inventory Sucessfully");
		}else {
			System.out.println("Error Saving Product In Inventory");
		}
	}
	
	public String getUrlByServiceName(String appName) {
		StringBuilder response = new StringBuilder();
		Application app = eurekaClient.getApplication(appName);
		InstanceInfo instance = app.getInstances().get(0);
		response.append(instance.getHomePageUrl());
		return response.toString();
	}

	@Override
    public Product getProductById(long productId) {
    	return productDao.getOne(productId);
    }
    
	@Override
    public void deleteProduct(long productId) { 
    	productDao.deleteById(productId);
    }

    @Override
	public Product updateProduct(Product product) {
		// TODO Auto-generated method stub
		Product prd = getProductById(product.getProductId());
		if(prd != null){
			prd.setCategory(product.getCategory());
			prd.setProductName(product.getProductName());
			prd.setDescription(product.getDescription());
			prd.setVendorId(product.getVendorId());
		}
		productDao.save(prd);
		return prd;
	}	
	
}
