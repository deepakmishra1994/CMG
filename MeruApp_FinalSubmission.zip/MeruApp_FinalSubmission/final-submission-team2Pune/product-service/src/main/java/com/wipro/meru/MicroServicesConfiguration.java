package com.wipro.meru;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.wipro.meru.service.ProductService;
import com.wipro.meru.service.ProductServiceImpl;


public class MicroServicesConfiguration {

}
