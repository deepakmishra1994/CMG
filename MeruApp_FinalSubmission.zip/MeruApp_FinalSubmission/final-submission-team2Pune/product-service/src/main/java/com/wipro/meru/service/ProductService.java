package com.wipro.meru.service;

import java.util.List;

import com.wipro.meru.entity.Product;

public interface ProductService {

	public List<Product> getAllProducts();

	public Product addProduct(Product product);

	public Product getProductById(long productId);

	public void deleteProduct(long productId);

	public Product updateProduct(Product product);
}
