package com.meru.priceservice.entities;

import javax.persistence.*;

/**
 * The persistent class for the price table of pricedb database.
 *
 */
@Entity
@Table(uniqueConstraints=@UniqueConstraint(columnNames="product_id"))
public class Price {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="price_id")
    private Long priceId;

    @Column(name="product_id", unique = true)
    private Long productId;

    private Long price;

    private String currency;

    public Price(){
    }

    public Price(Long priceId, Long productId, Long price, String currency) {
        this.priceId = priceId;
        this.productId = productId;
        this.price = price;
        this.currency = currency;
    }

    public Long getPriceId() {
        return priceId;
    }

    public void setPriceId(Long priceId) {
        this.priceId = priceId;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public Long getPrice() {
        return price;
    }

    public void setPrice(Long price) {
        this.price = price;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    @Override
    public String toString() {
        return "Price{" +
                "priceId=" + priceId +
                ", productId=" + productId +
                ", price=" + price +
                ", currency='" + currency + '\'' +
                '}';
    }
}
