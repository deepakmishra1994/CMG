package com.meru.priceservice.service;

import com.meru.priceservice.dto.PriceDTO;
import com.meru.priceservice.entities.Price;

import javax.persistence.EntityNotFoundException;

import org.springframework.http.ResponseEntity;

import java.util.List;

public interface IPriceService {
    Price getPriceByProductId(Long productId) throws EntityNotFoundException;
    Price addPrice(Price price) throws IllegalAccessException;
    Price updatePriceByProductId(Long productId,Price price) throws EntityNotFoundException;
    void deletePriceByProductId(Long productId);
    List<Price> getPriceByProductIds(List<Long> productIds) throws IllegalAccessException;
	ResponseEntity<PriceDTO> addProduct(Long productId);
}
