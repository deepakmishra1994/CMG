package com.meru.priceservice.dto;

import com.meru.priceservice.entities.Price;

public class PriceDTO {

    private Price price;
    private String errorMessage;
    private String port;

    public Price getPrice() {
        return price;
    }

    public void setPrice(Price price) {
        this.price = price;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    @Override
    public String toString() {
        return "PriceDTO{" +
                "price=" + price +
                ", errorMessage='" + errorMessage + '\'' +
                ", port='" + port + '\'' +
                '}';
    }
}
