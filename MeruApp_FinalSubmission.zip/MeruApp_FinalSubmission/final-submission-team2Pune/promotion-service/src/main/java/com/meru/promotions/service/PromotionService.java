package com.meru.promotions.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Date;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.meru.promotions.domain.NewPromoCodeRequest;
import com.meru.promotions.domain.NewPromotionRequest;
import com.meru.promotions.domain.PromoResponse;
import com.meru.promotions.domain.PromotionResponse;
import com.meru.promotions.entities.Promotion;
import com.meru.promotions.entities.PromoCode;
import com.meru.promotions.repository.PromotionRepository;

import com.meru.promotions.repository.PromoRepository;

@Service
public class PromotionService {

	private static final Logger log = LoggerFactory.getLogger(PromotionService.class);

	@Autowired
	private PromotionRepository promotionRepository;

	@Autowired
	private PromoRepository promoRepository;

	public ResponseEntity<PromotionResponse> addProduct(Long productId) {
		ResponseEntity<PromotionResponse> response = null;
		PromotionResponse resp = new PromotionResponse();
		try {
			Promotion promotion = new Promotion();
			promotion.setProductId(productId);
			promotion.setCreatedDate(new Date());
			promotion.setModifiedDate(new Date());
			Promotion savedEntity = promotionRepository.save(promotion);
			if(savedEntity != null) {
				resp.setProductId(productId);
				resp.setStatus(true);
				resp.setMessage("Successfully Saved");
				log.info("Saved Promotion :: "+ savedEntity.toString());
				response = new ResponseEntity<>(resp, HttpStatus.OK);
			}else {
				resp.setStatus(false);
				resp.setMessage("Unable To Save Promotion For Product Id "+ productId);
				response = new ResponseEntity<>(resp,HttpStatus.SERVICE_UNAVAILABLE);
			}
		}catch(DataIntegrityViolationException e) {
			e.printStackTrace();
			resp.setStatus(false);
			resp.setMessage("Product Already Exists For Product Id "+ productId);
			response = new ResponseEntity<>(resp,HttpStatus.NOT_ACCEPTABLE);
		}catch(Exception e) {
			resp.setStatus(false);
			resp.setMessage("Internal Server Issue");
			e.printStackTrace();
			response = new ResponseEntity<>(resp,HttpStatus.SERVICE_UNAVAILABLE);
		}
		return response;
	}

	public ResponseEntity<PromotionResponse> createNewPromotion(NewPromotionRequest request){
		ResponseEntity<PromotionResponse> response = null;
		log.info("Request Object :: "+ request.toString());
		try {
			if(request != null) {
				Promotion promotionEntity = promotionRepository.findByProductId(request.getProductId());
				PromoCode promoCode = getOrSavePromoCode(request);
				if(promotionEntity != null) {
					promotionEntity.setModifiedDate(new Date());
				}else {
					promotionEntity = new Promotion();
					promotionEntity.setCreatedDate(new Date());
					promotionEntity.setModifiedDate(new Date());
				}
				promotionEntity.setProductId(request.getProductId());
				promotionEntity.setPromoCode(promoCode);
				Promotion savedEntity = promotionRepository.save(promotionEntity);
				if(savedEntity != null) {
					log.info("Saved Promotion :: "+ savedEntity.toString());
					PromotionResponse promotionResponse = mapPromotionEntityToDomian(savedEntity);
					response = new ResponseEntity<>(promotionResponse, HttpStatus.OK);
				}else {
					PromotionResponse promotionResponse = new PromotionResponse();
					promotionResponse.setStatus(false);
					promotionResponse.setMessage("Unable To Fetch Promotion");
					response = new ResponseEntity<>(promotionResponse, HttpStatus.SERVICE_UNAVAILABLE);
				}
			}
		}catch(Exception e) {
			PromotionResponse promotionResponse = new PromotionResponse();
			promotionResponse.setStatus(false);
			promotionResponse.setMessage("Server Issue");
			e.printStackTrace();
			log.error(e.toString());
			response = new ResponseEntity<>(promotionResponse ,HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	private PromotionResponse mapPromotionEntityToDomian(Promotion savedEntity) {
		PromotionResponse response = new PromotionResponse();
		PromoCode promo = savedEntity.getPromoCode();
		response.setProductId(savedEntity.getProductId());
		if(promo != null) {
			response.setDiscountPercentage(promo.getDiscountPercentage());
			response.setEndDate(promo.getEndDate());
			response.setStartDate(promo.getStartDate());
			response.setPromoCode(promo.getPromoCode());
			response.setOfferExipryIn(setRemianingTime(promo.getStartDate(),promo.getEndDate()));
		}
		response.setStatus(true);
		response.setMessage("Promotion For Product Id " + savedEntity.getProductId());
		return response;
	}

	public PromoCode getOrSavePromoCode(NewPromotionRequest request) {
		PromoCode promoCodeEntity = promoRepository.findByPromoCode(request.getPromoCode());
		if(promoCodeEntity != null) {
			promoCodeEntity.setModifiedDate(new Date());
		}else {
			promoCodeEntity = new PromoCode();
			promoCodeEntity.setCreatedDate(new Date());
			promoCodeEntity.setModifiedDate(new Date());
		}
		promoCodeEntity.setStartDate(request.getStartDate());
		promoCodeEntity.setEndDate(request.getEndDate());
		promoCodeEntity.setDiscountPercentage(request.getDiscountPercentage());
		promoCodeEntity.setOfferExpirationIn(setRemianingTime(request.getStartDate(), request.getEndDate()));
		promoCodeEntity.setPromoCode(request.getPromoCode());
		PromoCode promo = promoRepository.save(promoCodeEntity);
		return promo;
	}
	
	public ResponseEntity<PromoResponse> createPromoCode(NewPromoCodeRequest request) {
		ResponseEntity<PromoResponse> resp = null;
		PromoResponse response = null;
		PromoCode promoCodeEntity = promoRepository.findByPromoCode(request.getPromoCode());
		try {
			if(promoCodeEntity != null) {
				throw new DataIntegrityViolationException("Promo Code Already Exists");
			}else {
				promoCodeEntity = new PromoCode();
				promoCodeEntity.setCreatedDate(new Date());
				promoCodeEntity.setModifiedDate(new Date());
			}
			promoCodeEntity.setStartDate(request.getStartDate());
			promoCodeEntity.setEndDate(request.getEndDate());
			promoCodeEntity.setDiscountPercentage(request.getDiscountPercent());
			promoCodeEntity.setOfferExpirationIn(setRemianingTime(request.getStartDate(), request.getEndDate()));
			promoCodeEntity.setPromoCode(request.getPromoCode());
			PromoCode promo = promoRepository.save(promoCodeEntity);
			response = mapPromoEntityToDomian(promo);
			response.setMessage("Promo Code Saved Succesfully");
			resp = new ResponseEntity<PromoResponse>(response, HttpStatus.OK);
		}catch(DataIntegrityViolationException e) {
			e.printStackTrace();
			response = new PromoResponse();
			response.setStatus(false);
			response.setMessage("Promo Code Already Exists");
			resp = new ResponseEntity<PromoResponse>(response, HttpStatus.NOT_ACCEPTABLE);
		}catch(Exception e) {
			e.printStackTrace();
			response = new PromoResponse();
			response.setStatus(false);
			response.setMessage("Server Issue");
			resp = new ResponseEntity<PromoResponse>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return resp;
	}
	
	private PromoResponse mapPromoEntityToDomian(PromoCode promo) {
		PromoResponse response = new PromoResponse();
		response.setDiscountPercentage(promo.getDiscountPercentage());
		response.setEndDate(promo.getEndDate());
		response.setStartDate(promo.getStartDate());
		response.setMessage("PromoCode");
		response.setStatus(true);
		response.setOfferExipryIn(setRemianingTime(promo.getStartDate(), promo.getEndDate()));
		response.setPromoCode(promo.getPromoCode());
		List<Promotion> promotions = promotionRepository.findByPromoCode(promo);
		List<Long> productList = new ArrayList<Long>();
		if(promotions != null && promotions.size() > 0) {
			promotions.forEach(pr -> {
				productList.add(pr.getProductId());
			});
		}
		response.setProductList(productList);
		return response;
	}

	private static String setRemianingTime(Date startDate, Date endDate) {  
		Long diff = endDate.getTime() - startDate.getTime(); 
		Long diffSeconds = diff / 1000 % 60;
		Long diffMinutes = diff / (60 * 1000) % 60; 
		Long diffHours = diff / (60 * 60 * 1000) % 24; 
		Long diffDays = diff / (24 * 60 * 60 * 1000);
		return diffDays.toString() + "Days, Time " + diffHours + ":" + diffMinutes + ":" + diffSeconds;
	}

	public ResponseEntity<PromotionResponse> getPromotionByProductId(Long productId) {
		ResponseEntity<PromotionResponse> response = null;
		PromotionResponse resp = new PromotionResponse();
		try {
			Promotion promotion = promotionRepository.findByProductId(productId);
			if(promotion != null) {
				 resp = mapPromotionEntityToDomian(promotion);
				response = new ResponseEntity<>(resp, HttpStatus.OK);
			}else{
				resp.setStatus(false);
				resp.setMessage("Promotion with Product Id Not Available");
				response = new ResponseEntity<>(resp, HttpStatus.NO_CONTENT);
			}
		}catch(Exception e){
			e.printStackTrace();
			log.error(e.toString());
			resp.setStatus(false);
			resp.setMessage("Server Issue");
			response = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	public ResponseEntity<PromoResponse> getPromotionByPromoCode(String promoCode) {
		ResponseEntity<PromoResponse> response = null;
		PromoResponse resp = new PromoResponse();
		try {
			PromoCode promoCodeEntity = promoRepository.findByPromoCode(promoCode);
			if(promoCodeEntity != null) {
				resp = mapPromoEntityToDomian(promoCodeEntity);
				response = new ResponseEntity<>(resp, HttpStatus.OK);
			}else {
				resp.setStatus(false);
				resp.setMessage("Promotion with PromoCode Not Available");
				response = new ResponseEntity<>(resp, HttpStatus.NO_CONTENT);
			}
		}catch(Exception e) {
			e.printStackTrace();				
			resp.setStatus(false);
			resp.setMessage("Server Issue");
			response = new ResponseEntity<>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	public ResponseEntity<List<PromotionResponse>> getAllPromotions() {
		ResponseEntity<List<PromotionResponse>> response = null;
		try {
			List<Promotion> promotionList = promotionRepository.findAll();
			if(promotionList != null && promotionList.size() > 0) {
				List<PromotionResponse> respList = new ArrayList<>();
				promotionList.forEach(promo -> respList.add(mapPromotionEntityToDomian(promo)));
				response = new ResponseEntity<>(respList, HttpStatus.OK);
			}else {
				response = new ResponseEntity<>(new ArrayList<>(), HttpStatus.NO_CONTENT);
			}
		}catch(Exception e) {
			e.printStackTrace();
			log.error(e.toString());
			response = new ResponseEntity<>(new ArrayList<>(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	public ResponseEntity<List<PromoResponse>> getAllPromoCodes() {
		ResponseEntity<List<PromoResponse>> response = null;
		try {
			List<PromoCode> promoList = promoRepository.findAll();
			if(promoList != null && promoList.size() > 0) {
				List<PromoResponse> resp = new ArrayList<PromoResponse>();
				promoList.forEach(promo -> resp.add(mapPromoEntityToDomian(promo)));
				response = new ResponseEntity<List<PromoResponse>>(resp, HttpStatus.OK);
			}else {
				response = new ResponseEntity<>(new ArrayList<>(), HttpStatus.NO_CONTENT);
			}
		}catch(Exception e) {
			e.printStackTrace();
			response = new ResponseEntity<>(new ArrayList<>(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}
	
}