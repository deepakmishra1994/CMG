package com.meru.promotions.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.TemporalType;
import javax.persistence.Temporal;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

@Entity
public class PromoCode implements Serializable{

	private static final long serialVersionUID = -89607029913562355L;

	@Id
	@GeneratedValue
	Long promoCodeId;
	
	@Column(unique = true)
	String promoCode;
	
	@Column
	private Double discountPercentage;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(nullable = false)
	private Date startDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(nullable = false)
	private Date endDate;
	
	@Column
	private String offerExpirationIn;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column
	@CreatedDate
	private Date createdDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column
	@LastModifiedDate
	private Date modifiedDate;

	public PromoCode() {
		super();
	}

	public Long getPromoCodeId() {
		return promoCodeId;
	}

	public void setPromoCodeId(Long promoCodeId) {
		this.promoCodeId = promoCodeId;
	}

	public String getPromoCode() {
		return promoCode;
	}

	public void setPromoCode(String promoCode) {
		this.promoCode = promoCode;
	}

	public Double getDiscountPercentage() {
		return discountPercentage;
	}

	public void setDiscountPercentage(Double discountPercentage) {
		this.discountPercentage = discountPercentage;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getOfferExpirationIn() {
		return offerExpirationIn;
	}

	public void setOfferExpirationIn(String offerExpirationIn) {
		this.offerExpirationIn = offerExpirationIn;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	@Override
	public String toString() {
		return "PromoCode [promoCodeId=" + promoCodeId + ", promoCode=" + promoCode + ", discountPercentage="
				+ discountPercentage + ", startDate=" + startDate + ", endDate=" + endDate + ", offerExpirationIn="
				+ offerExpirationIn + ", createdDate=" + createdDate + ", modifiedDate=" + modifiedDate + "]";
	}
}
