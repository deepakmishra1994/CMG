package com.meru.promotions.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.TemporalType;
import javax.persistence.Temporal;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

@Entity
public class Promotion implements Serializable{

	private static final long serialVersionUID = 6957064216835034193L;

	@Id
	@GeneratedValue
	private Long promotionId;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "promoCodeId")
	private PromoCode promoCode;

	@Column(unique = true)
	private Long productId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column
	@CreatedDate
	private Date createdDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column
	@LastModifiedDate
	private Date modifiedDate;

	public Promotion(Long promotionId, PromoCode promotionType, String promotionName, Long productId,
			String promoCode, Double discountPercentage, Date starDate, Date endDate, String offerExpirationIn,
			Date createdDate, Date modifiedDate) {
		super();
		this.promotionId = promotionId;
		this.productId = productId;
		this.createdDate = createdDate;
		this.modifiedDate = modifiedDate;
	}

	public Promotion() {

	}

	public Long getPromotionId() {
		return promotionId;
	}

	public void setPromotionId(Long promotionId) {
		this.promotionId = promotionId;
	}

	public PromoCode getPromoCode() {
		return promoCode;
	}

	public void setPromoCode(PromoCode promoCode) {
		this.promoCode = promoCode;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	@Override
	public String toString() {
		return "Promotion [promotionId=" + promotionId + ", productId=" + productId
				+ ", createdDate=" + createdDate + ", modifiedDate=" + modifiedDate + "]";
	}

	
}
