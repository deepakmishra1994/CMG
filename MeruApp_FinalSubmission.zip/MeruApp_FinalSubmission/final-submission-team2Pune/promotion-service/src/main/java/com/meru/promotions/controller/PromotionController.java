package com.meru.promotions.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.meru.promotions.domain.NewPromoCodeRequest;
import com.meru.promotions.domain.NewPromotionRequest;
import com.meru.promotions.domain.PromoResponse;
import com.meru.promotions.domain.PromotionResponse;
import com.meru.promotions.service.PromotionService;

@RestController
@RequestMapping("/promotion")
public class PromotionController {

	@Autowired
	private PromotionService promotionService;
	
	@RequestMapping(value = "/addProduct", method = RequestMethod.POST)
	public ResponseEntity<PromotionResponse> addProduct(@RequestBody Long productId){
		return promotionService.addProduct(productId);
	}
	
	@RequestMapping(value = "/createPromotion", method = RequestMethod.POST )
	public ResponseEntity<PromotionResponse> createPromotion(@RequestBody NewPromotionRequest request){
		return promotionService.createNewPromotion(request); 
	}
	
	@RequestMapping(value = "/getPromotionByProductId", method = RequestMethod.GET)
	public ResponseEntity<PromotionResponse> getPromotionByProductId(@RequestParam Long productId){ 
		return promotionService.getPromotionByProductId(productId); 
	}
	
	 @RequestMapping(value= "/findByPromoCode", method = RequestMethod.GET)
	 public ResponseEntity<PromoResponse> findByPromoCode(@RequestParam String promoCode){
		 return promotionService.getPromotionByPromoCode(promoCode); 
	 }
	 
	@RequestMapping(value = "/getAllPromotions", method = RequestMethod.GET)
	public ResponseEntity<List<PromotionResponse>> getAllPromotions(){
		return promotionService.getAllPromotions();
	}
	
	@RequestMapping(value = "/createPromoCode", method = RequestMethod.POST)
	public ResponseEntity<PromoResponse> createPromoCode(@RequestBody NewPromoCodeRequest request){
		return promotionService.createPromoCode(request);
	}
	
	@RequestMapping(value = "/getAllPromoCode", method = RequestMethod.GET)
	public ResponseEntity<List<PromoResponse>> getAllPromoCode(){
		return promotionService.getAllPromoCodes();
	}
}