package com.meru.promotions.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.meru.promotions.entities.PromoCode;
import com.meru.promotions.entities.Promotion;

@Repository
public interface PromotionRepository extends JpaRepository<Promotion, Long>{
	
	Promotion findByProductId(Long productId);
	List<Promotion> findByPromoCode(PromoCode promoCode);

}