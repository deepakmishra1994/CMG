package com.meru.promotions.domain;

import java.util.Date;

public class NewPromotionRequest {
	
	private Long productId;
	private Double discountPercentage;
	private String promoCode;
	private Date startDate;
	private Date endDate;
	
	public NewPromotionRequest() {
		super();
	}
	
	public NewPromotionRequest(String promotionType, Long productId, Double discountPercentage, String promoCode,
			String promotionName, String startDate, String endDate) {
		super();
		this.productId = productId;
		this.discountPercentage = discountPercentage;
		this.promoCode = promoCode;
	}


	public Long getProductId() {
		return productId;
	}
	public void setProductId(Long productId) {
		this.productId = productId;
	}
	public Double getDiscountPercentage() {
		return discountPercentage;
	}
	public void setDiscountPercentage(Double discountPercentage) {
		this.discountPercentage = discountPercentage;
	}
	public String getPromoCode() {
		return promoCode;
	}
	public void setPromoCode(String promoCode) {
		this.promoCode = promoCode;
	}

	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	
	@Override
	public String toString() {
		return "NewPromotionRequest [productId=" + productId
				+ ", discountPercentage=" + discountPercentage + ", promoCode=" + promoCode + ", startDate=" + startDate + ", endDate=" + endDate + "]";
	}
	
}
