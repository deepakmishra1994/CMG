package com.meru.promotions.domain;

import java.util.Date;

public class PromotionResponse {

	private Long productId;
	private Double discountPercentage;
	private Date startDate;
	private Date endDate;
	private String offerExipryIn;
	private String promoCode;
	private Boolean status;
	private String message;
	
	public Long getProductId() {
		return productId;
	}
	public void setProductId(Long productId) {
		this.productId = productId;
	}
	public Double getDiscountPercentage() {
		return discountPercentage;
	}
	public void setDiscountPercentage(Double discountPercentage) {
		this.discountPercentage = discountPercentage;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public String getOfferExipryIn() {
		return offerExipryIn;
	}
	public void setOfferExipryIn(String offerExipryIn) {
		this.offerExipryIn = offerExipryIn;
	}
	public String getPromoCode() {
		return promoCode;
	}
	public void setPromoCode(String promoCode) {
		this.promoCode = promoCode;
	}
	public Boolean getStatus() {
		return status;
	}
	public void setStatus(Boolean status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	@Override
	public String toString() {
		return "PromotionResponse [productId=" + productId + ", discountPercentage=" + discountPercentage
				+ ", startDate=" + startDate + ", endDate=" + endDate + ", offerExipryIn=" + offerExipryIn
				+ ", promoCode=" + promoCode + ", status=" + status + ", message=" + message + "]";
	}
	
}
