package com.meru.promotions.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.meru.promotions.entities.PromoCode;

@Repository
public interface PromoRepository extends JpaRepository<PromoCode, Long>{

	PromoCode findByPromoCode(String promoCode);

	//PromoCode findByPromotionTypeName(String promotionName);
	
}
