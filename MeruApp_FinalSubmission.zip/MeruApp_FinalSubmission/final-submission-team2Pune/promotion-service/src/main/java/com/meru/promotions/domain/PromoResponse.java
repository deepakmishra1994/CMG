package com.meru.promotions.domain;

import java.util.Date;
import java.util.List;

public class PromoResponse {
	
	private String promoCode;
	private Double discountPercentage;
	private Date startDate;
	private Date endDate;
	private String offerExipryIn;
	private List<Long> productList;
	private Boolean status;
	private String message;
	
	public String getPromoCode() {
		return promoCode;
	}
	public void setPromoCode(String promoCode) {
		this.promoCode = promoCode;
	}
	public Double getDiscountPercentage() {
		return discountPercentage;
	}
	public void setDiscountPercentage(Double discountPercentage) {
		this.discountPercentage = discountPercentage;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public String getOfferExipryIn() {
		return offerExipryIn;
	}
	public void setOfferExipryIn(String offerExipryIn) {
		this.offerExipryIn = offerExipryIn;
	}
	public List<Long> getProductList() {
		return productList;
	}
	public void setProductList(List<Long> productList) {
		this.productList = productList;
	}
	public Boolean getStatus() {
		return status;
	}
	public void setStatus(Boolean status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	@Override
	public String toString() {
		return "PromoResponse [promoCode=" + promoCode + ", discountPercentage=" + discountPercentage + ", startDate="
				+ startDate + ", endDate=" + endDate + ", offerExipryIn=" + offerExipryIn + ", productList="
				+ productList + ", status=" + status + ", message=" + message + "]";
	}
}
