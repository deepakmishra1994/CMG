/*
 * package com.meru.promotion.services;
 * 
 * import java.util.List;
 * 
 * import static org.junit.Assert.assertTrue; import static
 * org.mockito.Mockito.when;
 * 
 * import java.util.ArrayList; import java.util.Date;
 * 
 * import org.junit.Before; import org.junit.Test; import
 * org.junit.runner.RunWith; import org.mockito.InjectMocks; import
 * org.mockito.Mock; import org.mockito.MockitoAnnotations; import
 * org.mockito.junit.MockitoJUnitRunner; import
 * org.springframework.http.ResponseEntity;
 * 
 * import com.meru.promotions.domain.NewPromotionRequest; import
 * com.meru.promotions.entities.Promotion; import
 * com.meru.promotions.entities.PromoCode; import
 * com.meru.promotions.repository.PromotionRepository; import
 * com.meru.promotions.repository.PromoRepository; import
 * com.meru.promotions.service.PromotionService;
 * 
 * @RunWith(MockitoJUnitRunner.class) public class PromotionServiceTest {
 * 
 * @InjectMocks private PromotionService promotionService;
 * 
 * @Mock private PromotionRepository promotionRepository;
 * 
 * @Mock private PromoRepository typeRepository;
 * 
 * private Promotion promotion; private PromoCode promotionType; private
 * List<Promotion> promoList = new ArrayList<>();
 * 
 * @Before public void init() { MockitoAnnotations.initMocks(this);
 * promotionType = new PromoCode(1l,"Type Name", new ArrayList<Promotion>(), new
 * Date(), new Date()); promotion = new
 * Promotion(1l,promotionType,"Promotion Name",2l,"Promo Code", 12.3d,new
 * Date(),new Date(),"23 Days",new Date(),new Date()); promoList.add(promotion);
 * promoList.add(new
 * Promotion(3l,promotionType,"Promotion Name 2",2l,"Promo Code 2", 16.3d,new
 * Date(),new Date(),"3 Days",new Date(),new Date()));
 * promotionType.setPromotion(promoList); }
 * 
 * @Test public void testGetAllPromotions() {
 * when(promotionRepository.findAll()).thenReturn(promoList);
 * ResponseEntity<List<Promotion>> response =
 * promotionService.getAllPromotions(); assertTrue(response.getBody().size() ==
 * promoList.size());
 * 
 * }
 * 
 * @Test public void testCreateNewPromotion() { NewPromotionRequest request =new
 * NewPromotionRequest("Promotion Type",1l,12.4d,"PROMO",
 * "PromotionName","31/12/2019 23:21:22", "31/12/2020 23:21:22");
 * when(typeRepository.findByPromotionTypeName("Promotion Type")).thenReturn(
 * promotionType);
 * when(promotionRepository.save(promotion)).thenReturn(promotion);
 * ResponseEntity<Promotion> response =
 * promotionService.createNewPromotion(request); assertTrue(response.getBody()
 * != null && response.getBody().getProductId() == 1l); }
 * 
 * }
 */