package com.dm.microservices.currencyconversionservice;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.dm.microservices.currencyconversionservice.bean.CurrencyConversionBean;

//static feign client
//@FeignClient(name="currency-exchange-service",url="http://localhost:8000")

//dynamic feign client with no url when integrated ribbon (loadbalancer)
//configure the url in application.properties of the current microservice
//connects the currency conversion service to the currency exchange service directly
//@FeignClient(name="currency-exchange-service")

//connects the currency conversion service to the currency exchange service through the Zuul API Gateway
@FeignClient(name="netflix-zuul-api-gateway-server")
@RibbonClient(name="currency-exchange-service")
public interface CurrencyExchangeServiceProxy {

	//@GetMapping("/currency-exchange/from/{from}/to/{to}")
    //http://localhost:8765/{application-name}/{uri}
    @GetMapping("/currency-exchange-service/currency-exchange/from/{from}/to/{to}")
    public CurrencyConversionBean retrieveExchangeValue(@PathVariable("from") String from, @PathVariable("to") String to);
	
}
